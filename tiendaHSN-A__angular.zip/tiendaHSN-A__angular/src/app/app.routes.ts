import { Routes } from '@angular/router';

//modulo de codigo donde se definen las rutas de navegacion
//de la aplicacion angular para el servicio Router de enrutamiento de angular
// se exporta un array de objetos "Route" de angular: https://angular.dev/api/router/Route
export const misRutas: Routes = [

];

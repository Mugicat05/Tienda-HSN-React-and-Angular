export default interface IRespuestaNode {
  codigo: number,
  mensaje: string,
  datos?: any
}
